// @author Michał Sadlej

#include <iostream>
#include "date.h"

int main(){
    Date my_date(15, 3, 2023);
    std::cout << my_date.get_day() << ".";
    std::cout << my_date.get_month() << ".";
    std::cout << my_date.get_year() << std::endl;

    my_date.set_month(2);
    my_date.set_year(2020);
    my_date.set_day(29);
    std::cout << my_date.get_day() << ".";
    std::cout << my_date.get_month() << ".";
    std::cout << my_date.get_year() << std::endl;

    my_date.set_year(2023);
    std::cout << my_date.get_day() << ".";
    std::cout << my_date.get_month() << ".";
    std::cout << my_date.get_year() << std::endl;

    my_date.set_month(9);
    my_date.set_year(2023);
    std::cout << my_date.get_day() << ".";
    std::cout << my_date.get_month() << ".";
    std::cout << my_date.get_year() << std::endl;

    return 0;
}
