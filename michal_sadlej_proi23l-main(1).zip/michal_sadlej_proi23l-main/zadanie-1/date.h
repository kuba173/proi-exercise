#pragma once

class Date{
    private:
        int day;
        int month;
        int year;
    public:
        Date(int day, int month, int year);
        int get_day();
        int get_month();
        int get_year();
        void set_day(int new_day);
        void set_month(int new_month);
        void set_year(int new_year);
        bool is_leap_year(int new_year);
        bool is_valid_date(int new_day, int new_month, int new_year);
};
