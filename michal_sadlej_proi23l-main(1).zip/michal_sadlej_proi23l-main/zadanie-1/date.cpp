/*
@author Michał Sadlej
class Date:
stores a date,
contains setters and getters for day, month and year,
checks the validity of given date.
*/

#include <iostream>
#include "date.h"

Date::Date(int new_day, int new_month, int new_year){
    if(is_valid_date(new_day, new_month, new_year)){
        day = new_day;
        month = new_month;
        year = new_year;
    }
    else{
        std::cout << "Given date is invalid!" << std::endl;
        day = 1;
        month = 1;
        year = 1;
    }
}

int Date::get_day(){
    return day;
}

int Date::get_month(){
    return month;
}

int Date::get_year(){
    return year;
}

void Date::set_day(int new_day){
    if(is_valid_date(new_day, month, year)){
        day = new_day;
    }
    else{
        std::cout << "Given date is invalid!" << std::endl;
    }
}

void Date::set_month(int new_month){
    if(is_valid_date(day, new_month, year)){
        month = new_month;
    }
    else{
        std::cout << "Given date is invalid!" << std::endl;
    }
}

void Date::set_year(int new_year){
    if(is_valid_date(day, month, new_year)){
        year = new_year;
    }
    else{
        std::cout << "Given date is invalid!" << std::endl;
    }
}

bool Date::is_leap_year(int new_year){
    if(new_year % 400 == 0){
        return true;
    }
    if(new_year % 100 == 0){
        return false;
    }
    if(new_year % 4 == 0){
        return true;
    }

    return false;
}

bool Date::is_valid_date(int new_day, int new_month, int new_year){
    if(new_day <= 0 || new_month <= 0 || new_year <= 0 || new_month > 12){
        return false;
    }

    if(new_month == 2){
        if(is_leap_year(new_year)){
            return new_day <= 29;
        }

        return new_day <= 28;
    }
    if((new_month % 2 == 1 && new_month <= 7) || (new_month % 2 == 0 && new_month > 7)){
        return new_day <= 31;
    }
    
    return new_day <= 30;
}
