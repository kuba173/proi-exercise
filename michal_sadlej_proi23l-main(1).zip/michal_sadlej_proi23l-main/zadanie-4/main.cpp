/*
@author Michał Sadlej
Program reads a calendar from a csv file.
Takes the path of the csv file as an argument.
*/

#include "../rapidcsv/rapidcsv.h"
#include "includes/csv_file.h"
#include "includes/json_file.h"
#include <sstream>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        std::cerr
            << "Incorrect number of command line arguments - expected 1, got "
            << argc - 1 << std::endl;
        return 1;
    }

    CsvFile csv_file(argv[1]);
    Calendar calendar = csv_file.getCalendar();

    JsonFile json_file("calendar.json");
    json_file.serializeCalendar(calendar);

    return 0;
}
