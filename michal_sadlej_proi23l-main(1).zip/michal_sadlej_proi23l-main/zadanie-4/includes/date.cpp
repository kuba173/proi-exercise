/*
@author Michał Sadlej
class Date:
represents a date,
stores the day, month and year,
defaults to 01.01.0001, Monday.
*/

#include "date.h"
#include "invalid_date_exception.h"
#include <iomanip>
#include <map>

std::map<Month, uint> months_length{
    {Month::January, 31}, {Month::February, 28}, {Month::March, 31},
    {Month::April, 30},   {Month::May, 31},      {Month::June, 30},
    {Month::July, 31},    {Month::August, 31},   {Month::September, 30},
    {Month::October, 31}, {Month::November, 30}, {Month::December, 31},
};

Date::Date()
    : day(1), month(Month::January), year(1), weekday(Weekday::Monday) {}

Date::Date(uint day, Month month, uint year)
    : day(day), month(month), year(year) {
    weekday = Weekday{computeWeekday()};

    if (!isValidDate()) {
        throw InvalidDateException(*this);
    }
}

uint Date::getDay() const { return day; }

Month Date::getMonth() const { return month; }

uint Date::getYear() const { return year; }

Weekday Date::getWeekday() const { return weekday; }

void Date::setDay(uint new_day) {
    day = new_day;
    weekday = Weekday{computeWeekday()};

    if (!isValidDate()) {
        throw InvalidDateException(*this);
    }
}

void Date::setMonth(Month new_month) {
    month = new_month;
    weekday = Weekday{computeWeekday()};

    if (!isValidDate()) {
        throw InvalidDateException(*this);
    }
}

void Date::setYear(uint new_year) {
    year = new_year;
    weekday = Weekday{computeWeekday()};

    if (!isValidDate()) {
        throw InvalidDateException(*this);
    }
}

bool Date::isFromSameWeek(const Date &other) const {
    // Construct chrono objects for both dates
    auto this_chrono = toChrono();
    auto other_chrono = other.toChrono();

    // Get the weekday numbers of both dates
    uint this_weekday = computeWeekday();
    uint other_weekday = other.computeWeekday();

    // Calculate the corresponding Sundays for both dates
    std::chrono::year_month_day this_sunday{
        std::chrono::floor<std::chrono::days>(
            std::chrono::sys_days{this_chrono} -
            std::chrono::days{this_weekday})};
    std::chrono::year_month_day other_sunday{
        std::chrono::floor<std::chrono::days>(
            std::chrono::sys_days{other_chrono} -
            std::chrono::days{other_weekday})};

    return this_sunday == other_sunday;
}

bool Date::isFromSameMonth(const Date &other) const {
    return month == other.getMonth() && year == other.getYear();
}

std::chrono::year_month_day Date::toChrono() const {
    return std::chrono::year_month_day{
        std::chrono::year{static_cast<int>(year)},
        std::chrono::month{static_cast<uint>(month)}, std::chrono::day{day}};
}

std::string Date::toString() const {
    std::stringstream stream;
    stream << *this;
    return stream.str();
}

bool Date::isValidDate() const {
    auto this_chrono = toChrono();

    return this_chrono.ok();
}

uint Date::computeWeekday() const {
    auto this_chrono = toChrono();

    return std::chrono::weekday{std::chrono::sys_days{this_chrono}}
        .c_encoding();
}

bool operator==(const Date &first, const Date &second) {
    auto first_chrono = first.toChrono();
    auto second_chrono = second.toChrono();

    return first_chrono == second_chrono;
}

bool operator<(const Date &first, const Date &second) {
    auto first_chrono = first.toChrono();
    auto second_chrono = second.toChrono();

    return first_chrono < second_chrono;
}

std::ostream &operator<<(std::ostream &stream, const Date &date) {
    stream << std::setfill('0') << std::setw(2) << date.getDay() << "."
           << std::setw(2) << static_cast<uint>(date.getMonth()) << "."
           << std::setw(4) << date.getYear();
    return stream;
}

std::istream &operator>>(std::istream &stream, Date &date) {
    uint day;
    uint month_number;
    uint year;
    char separator;

    stream >> day >> separator >> month_number >> separator >> year;
    date.setDay(day);
    date.setMonth(Month(month_number));
    date.setYear(year);

    return stream;
}
