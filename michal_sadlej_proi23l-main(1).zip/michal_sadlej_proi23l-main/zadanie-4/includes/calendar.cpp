/*
@author Michał Sadlej
class Calendar:
represents a personal calendar,
stores a list of events,
defaults to an empty calendar.
*/

#include "calendar.h"
#include <algorithm>

Calendar::Calendar(std::list<Event> events_list) : events_list(events_list) {}

std::list<Event> Calendar::getEvents() const { return events_list; }

std::list<Event> Calendar::getEventsTitled(const std::string &title) const {
    std::list<Event> result;
    auto begin = events_list.begin();
    auto end = events_list.end();

    std::copy_if(begin, end, std::back_inserter(result),
                 [title](Event event) { return event.getTitle() == title; });
    return result;
}

std::list<Event> Calendar::getEventsSorted() const {
    auto result = events_list;

    result.sort([](const Event &first, const Event &second) {
        return first.getDate() < second.getDate();
    });
    return result;
}

uint Calendar::countEventsOnDay(Date date) const {
    auto begin = events_list.begin();
    auto end = events_list.end();

    return std::count_if(
        begin, end, [date](Event event) { return event.getDate() == date; });
}

uint Calendar::countEventsOnWeek(Date date) const {
    auto begin = events_list.begin();
    auto end = events_list.end();

    return std::count_if(begin, end, [date](Event event) {
        return date.isFromSameWeek(event.getDate());
    });
}

uint Calendar::countEventsOnMonth(Date date) const {
    auto begin = events_list.begin();
    auto end = events_list.end();

    return std::count_if(begin, end, [date](Event event) {
        return date.isFromSameMonth(event.getDate());
    });
}

uint Calendar::countEventsTitled(const std::string &title) const {
    auto begin = events_list.begin();
    auto end = events_list.end();

    return std::count_if(
        begin, end, [title](Event event) { return event.getTitle() == title; });
}

void Calendar::addEvent(Event event) { events_list.push_back(event); }

void Calendar::removeEvent(Event event) { events_list.remove(event); }
