/*
@author Michał Sadlej
class JsonFile:
writes a Calendar to a json file.
*/

#include "json_file.h"
#include <fstream>

JsonFile::JsonFile(std::string path) : path(path) {}

void JsonFile::serializeCalendar(Calendar calendar) {
    nlohmann::json calendar_json;
    auto events = calendar.getEvents();

    for (auto event : events) {
        nlohmann::json event_json;
        event_json["title"] = event.getTitle();
        event_json["date"] = event.getDate().toString();
        event_json["time"] = event.getTime().toString();
        calendar_json.push_back(event_json);
    }
    std::ofstream json_file(path);
    json_file << calendar_json.dump() << std::endl;
    json_file.close();
}
