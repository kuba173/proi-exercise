#pragma once
#include <chrono>
#include <iostream>

typedef unsigned int uint;
enum class Month : uint {
    January = 1,
    February,
    March,
    April,
    May,
    June,
    July,
    August,
    September,
    October,
    November,
    December
};
enum class Weekday : uint {
    Sunday = 0,
    Monday,
    Tuesday,
    Wednesday,
    Thursday,
    Friday,
    Saturday
};

class Date {
  private:
    uint day;
    Month month;
    uint year;
    Weekday weekday;
    bool isValidDate() const;
    uint computeWeekday() const;

  public:
    Date();
    Date(uint, Month, uint);
    uint getDay() const;
    Month getMonth() const;
    uint getYear() const;
    Weekday getWeekday() const;
    void setDay(uint);
    void setMonth(Month);
    void setYear(uint);
    bool isFromSameWeek(const Date &) const;
    bool isFromSameMonth(const Date &) const;
    std::chrono::year_month_day toChrono() const;
    std::string toString() const;
};

bool operator==(const Date &, const Date &);
bool operator<(const Date &, const Date &);
std::ostream &operator<<(std::ostream &, const Date &);
std::istream &operator>>(std::istream &, Date &);
