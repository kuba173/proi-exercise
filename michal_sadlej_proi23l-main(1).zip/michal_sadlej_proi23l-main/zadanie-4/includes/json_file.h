#pragma once
#include "../../nlohmann/json.hpp"
#include "calendar.h"

class JsonFile {
  private:
    std::string path;

  public:
    JsonFile(std::string);
    void serializeCalendar(Calendar);
};
