#pragma once
#include <stdexcept>

class EmptyTitleException : public std::invalid_argument {
  public:
    EmptyTitleException();
};
