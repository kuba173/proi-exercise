/*
@author Michał Sadlej
class Date:
represents a date,
stores the day, month and year.
*/

#include <iomanip>
#include <map>
#include "date.h"

std::map<Month, uint> months_length{
    {January, 31},
    {February, 28},
    {March, 31},
    {April, 30},
    {May, 31},
    {June, 30},
    {July, 31},
    {August, 31},
    {September, 30},
    {October, 31},
    {November, 30},
    {December, 31},
};

Date::Date() : day(1), month(January), year(1), weekday(Monday){}

Date::Date(uint day, Month month, uint year) : Date(){
    if(isValidDate(day, month, year)){
        this->day = day;
        this->month = month;
        this->year = year;
        this->weekday = computeWeekday();
    }
    else{
        std::cerr << "Given date is invalid!" << std::endl;
    }
}

uint Date::getDay() const{
    return this->day;
}

Month Date::getMonth() const{
    return this->month;
}

uint Date::getYear() const{
    return this->year;
}

Weekday Date::getWeekday() const{
    return this->weekday;
}

void Date::setDay(uint day){
    if(isValidDate(day, this->month, this->year)){
        this->day = day;
        this->weekday = computeWeekday();
    }
    else{
        std::cerr << "Given date is invalid!" << std::endl;
    }
}

void Date::setMonth(Month month){
    if(isValidDate(this->day, month, this->year)){
        this->month = month;
        this->weekday = computeWeekday();
    }
    else{
        std::cerr << "Given date is invalid!" << std::endl;
    }
}

void Date::setYear(uint year){
    if(isValidDate(this->day, this->month, year)){
        this->year = year;
        this->weekday = computeWeekday();
    }
    else{
        std::cerr << "Given date is invalid!" << std::endl;
    }
}

Weekday Date::computeWeekday() const{
    std::tm timeIn = {0, 0, 0,
        static_cast<int>(this->day),
        static_cast<int>(this->month) - 1,
        static_cast<int>(this->year) - 1900
    };
    std::time_t timeTemp = std::mktime(&timeIn);
    std::tm* timeOut = std::localtime(&timeTemp);

    return Weekday(timeOut->tm_wday);
}

bool Date::isFromSameWeek(const Date& other) const{
    Date this_saturday = *this + (6 - static_cast<uint>(this->weekday));
    Date other_saturday = other + (6 - static_cast<uint>(other.getWeekday()));

    return this_saturday == other_saturday;
}

bool Date::isFromSameMonth(const Date& other) const{
    return this->month == other.getMonth() && this->year == other.getYear();
}

bool Date::isLeapYear(uint year) const{
    if(year % 400 == 0){
        return true;
    }
    if(year % 100 == 0){
        return false;
    }
    if(year % 4 == 0){
        return true;
    }

    return false;
}

bool Date::isValidDate(uint day, Month month, uint year) const{
    if(isLeapYear(year) && month == February){
        return day <= months_length[month] + 1;
    }

    return day <= months_length[month];
}

bool operator==(const Date& first, const Date& second){
    return first.getDay() == second.getDay() &&
        first.getMonth() == second.getMonth() &&
        first.getYear() == second.getYear();
}

Date operator+(const Date& date, uint days){
    uint day = date.getDay() + days;
    Month month = date.getMonth();
    uint year = date.getYear();

    while(!date.isValidDate(day, month, year)){
        if(date.isLeapYear(year) && month == February){
            day -= months_length[month] + 1;
            month = March;
        }
        else if(month == December){
            day -= months_length[month];
            month = January;
            year += 1;
        }
        else{
            day -= months_length[month];
            month = static_cast<Month>(month + 1);
        }
    }

    return Date(day, month, year);
}

std::ostream& operator<<(std::ostream& stream, const Date& date){
    stream << std::setfill('0') << std::setw(2) << date.getDay() << "."
       << std::setw(2) << date.getMonth() << "." << std::setw(4) << date.getYear();
    return stream;
}

std::istream& operator>>(std::istream& stream, Date& date){
    uint day;
    uint month_number;
    uint year;
    char _;

    stream >> day >> _ >> month_number >> _ >> year;
    date.setDay(day);
    date.setMonth(Month(month_number));
    date.setYear(year);

    return stream;
}
