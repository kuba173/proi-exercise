#pragma once

#include <iostream>
typedef unsigned int uint;

class Time{
    private:
        uint hour;
        uint minute;
    public:
        Time();
        Time(uint, uint);
        uint getHour() const;
        uint getMinute() const;
        void setHour(uint);
        void setMinute(uint);
};

bool operator==(const Time&, const Time&);
std::ostream& operator<<(std::ostream&, const Time&);
std::istream& operator>>(std::istream&, Time&);
