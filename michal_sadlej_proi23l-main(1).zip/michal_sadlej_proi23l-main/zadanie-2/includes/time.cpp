/*
@author Michał Sadlej
class Time:
represents a time,
stores the hour and minute.
*/

#include <iomanip>
#include "time.h"

Time::Time() : hour(0), minute(0){}

Time::Time(uint hour, uint minute) : Time(){
    if(minute < 60 && hour < 24){
        this->hour = hour;
        this->minute = minute;
    }
    else{
        std::cerr << "Given time is invalid!" << std::endl;
    }
}

uint Time::getHour() const{
    return this->hour;
}

uint Time::getMinute() const{
    return this->minute;
}

void Time::setHour(uint hour){
    if(hour < 24){
        this->hour = hour;
    }else{
        std::cerr << "Given time is invalid!" << std::endl;
    }
}

void Time::setMinute(uint minute){
    if(minute < 60){
        this->minute = minute;
    }else{
        std::cerr << "Given time is invalid!" << std::endl;
    }
}

bool operator==(const Time& first, const Time& second){
    return first.getHour() == second.getHour() &&
        first.getMinute() == second.getMinute();
}

std::ostream& operator<<(std::ostream& stream, const Time& time){
    stream << std::setfill('0') << std::setw(2) << time.getHour() << ":"
       << std::setw(2) << time.getMinute();
    return stream;
}

std::istream& operator>>(std::istream& stream, Time& time){
    uint hour;
    uint minute;
    char _;

    stream >> hour >> _ >> minute;
    time.setHour(hour);
    time.setMinute(minute);

    return stream;
}
