/*
@author Michał Sadlej
class Calendar:
represents a personal calendar,
stores a list of events.
*/

#include <algorithm>
#include "calendar.h"

Calendar::Calendar(){}

Calendar::Calendar(std::list<Event> events_list) : Calendar(){
    this->events_list = events_list;
}

std::list<Event> Calendar::getEvents() const{
    return this->events_list;
}

uint Calendar::countEventsOnDay(Date date) const{
    auto begin = this->events_list.begin();
    auto end = this->events_list.end();

    return std::count_if(begin, end, [date](Event event){return event.getDate() == date;});
}

uint Calendar::countEventsOnWeek(Date date) const{
    auto begin = this->events_list.begin();
    auto end = this->events_list.end();

    return std::count_if(begin, end, [date](Event event){return date.isFromSameWeek(event.getDate());});
}

uint Calendar::countEventsOnMonth(Date date) const{
    auto begin = this->events_list.begin();
    auto end = this->events_list.end();

    return std::count_if(begin, end, [date](Event event){return date.isFromSameMonth(event.getDate());});
}

void Calendar::addEvent(Event event){
    this->events_list.push_back(event);
}

void Calendar::removeEvent(Event event){
    this->events_list.remove(event);
}

std::ostream& operator<<(std::ostream& stream, const Calendar& calendar){
    stream << "Calendar:" << std::endl;
    for(Event event : calendar.getEvents()){
        stream << "\t" << event << std::endl;
    }

    return stream;
}
