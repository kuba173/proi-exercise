#pragma once

#include <iostream>
typedef unsigned int uint;
enum Month{
    January = 1, February, March, April, May, June, 
    July, August, September, October, November, December
};
enum Weekday{
    Sunday = 0, Monday, Tuesday,
    Wednesday, Thursday, Friday, Saturday
};

class Date{
    private:
        uint day;
        Month month;
        uint year;
        Weekday weekday;
        Weekday computeWeekday() const;
    public:
        Date();
        Date(uint, Month, uint);
        uint getDay() const;
        Month getMonth() const;
        uint getYear() const;
        Weekday getWeekday() const;
        void setDay(uint);
        void setMonth(Month);
        void setYear(uint);
        bool isFromSameWeek(const Date&) const;
        bool isFromSameMonth(const Date&) const;
        bool isLeapYear(uint) const;
        bool isValidDate(uint, Month, uint) const;
};

bool operator==(const Date&, const Date&);
Date operator+(const Date&, uint);
std::ostream& operator<<(std::ostream&, const Date&);
std::istream& operator>>(std::istream&, Date&);
