#pragma once

#include "event.h"

class Calendar{
    private:
        std::list<Event> events_list;
    public:
        Calendar();
        Calendar(std::list<Event>);
        std::list<Event> getEvents() const;
        uint countEventsOnDay(Date) const;
        uint countEventsOnWeek(Date) const;
        uint countEventsOnMonth(Date) const;
        void addEvent(Event);
        void removeEvent(Event);
};

std::ostream& operator<<(std::ostream&, const Calendar&);
