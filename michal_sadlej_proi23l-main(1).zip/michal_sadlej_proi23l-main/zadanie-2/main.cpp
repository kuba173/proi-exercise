/*
@author Michał Sadlej
*/

#include <sstream>
#include "includes/calendar.h"

int main(int argc, char* argv[]){
    if(argc != 4)
    {
        std::cerr << "Incorrect number of command line arguments - expected 3, got " << argc - 1 << std::endl;
        return 1;
    }

    Event event;
    std::stringstream stream;

    stream << argv[1] << " " << argv[2] << " " << argv[3];
    stream >> event;

    Calendar calendar;
    calendar.addEvent(event);
    std::cout << calendar;

    Date date1(20, March, 2023);
    Time time1(1, 46);
    Event event1("Jeden", date1, time1);
    calendar.addEvent(event1);

    Date date2(24, March, 2023);
    Time time2(15, 20);
    Event event2("Dwa", date2, time2);
    calendar.addEvent(event2);

    Date date3(15, March, 2023);
    Time time3(12, 25);
    Event event3("Trzy", date3, time3);
    calendar.addEvent(event3);

    calendar.addEvent(Event());

    std::cout << "Day: " << calendar.countEventsOnDay(event.getDate()) << std::endl;
    std::cout << "Week: " << calendar.countEventsOnWeek(event.getDate()) << std::endl;
    std::cout << "Month: " << calendar.countEventsOnMonth(event.getDate()) << std::endl;
    std::cout << calendar;

    return 0;
}
