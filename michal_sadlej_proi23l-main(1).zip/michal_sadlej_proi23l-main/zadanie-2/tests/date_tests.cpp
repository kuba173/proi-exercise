#include "../../catch2/catch_amalgamated.hpp"
#include "../includes/date.h"
#include <sstream>

TEST_CASE("date tests", "[date]"){
    Date date(25, March, 2023);

    CHECK(date.getDay() == 25);
    CHECK(date.getMonth() == March);
    CHECK(date.getYear() == 2023);
    CHECK(date.getWeekday() == Saturday);

    SECTION("default constructor"){
        Date default_date;

        CHECK(default_date.getDay() == 1);
        CHECK(default_date.getMonth() == January);
        CHECK(default_date.getYear() == 1);
        CHECK(default_date.getWeekday() == Monday);
    }

    SECTION("day setter"){
        date.setDay(22);

        CHECK(date.getDay() == 22);
        CHECK(date.getMonth() == March);
        CHECK(date.getYear() == 2023);
        CHECK(date.getWeekday() == Wednesday);
    }

    SECTION("month setter"){
        date.setMonth(February);

        CHECK(date.getDay() == 25);
        CHECK(date.getMonth() == February);
        CHECK(date.getYear() == 2023);
        CHECK(date.getWeekday() == Saturday);
    }

    SECTION("year setter"){
        date.setYear(2022);

        CHECK(date.getDay() == 25);
        CHECK(date.getMonth() == March);
        CHECK(date.getYear() == 2022);
        CHECK(date.getWeekday() == Friday);
    }

    SECTION("same week"){
        Date other(19, March, 2023);

        CHECK(date.isFromSameWeek(other));
        other.setDay(26);
        CHECK(!date.isFromSameWeek(other));
        other.setDay(19);
        other.setMonth(April);
        CHECK(!date.isFromSameMonth(other));
    }

    SECTION("same month"){
        Date other(19, March, 2023);

        CHECK(date.isFromSameMonth(other));
        other.setMonth(April);
        CHECK(!date.isFromSameMonth(other));
        other.setMonth(March);
        other.setYear(2022);
    }

    SECTION("operator =="){
        Date other(25, March, 2023);

        CHECK(date == other);
        other.setDay(24);
        CHECK(!(date == other));
        other.setDay(25);
        other.setMonth(February);
        CHECK(!(date == other));
        other.setMonth(March);
        other.setYear(2022);
    }

    SECTION("operator +"){
        date.setMonth(November);
        Date other;

        other = date + 3;
        CHECK(other.getDay() == 28);
        CHECK(other.getMonth() == November);
        CHECK(other.getYear() == 2023);
        CHECK(other.getWeekday() == Tuesday);

        other = date + 7;
        CHECK(other.getDay() == 2);
        CHECK(other.getMonth() == December);
        CHECK(other.getYear() == 2023);
        CHECK(other.getWeekday() == Saturday);

        other = date + 46;
        CHECK(other.getDay() == 10);
        CHECK(other.getMonth() == January);
        CHECK(other.getYear() == 2024);
        CHECK(other.getWeekday() == Wednesday);
    }

    SECTION("iostream operators"){
        Date other;
        std::stringstream stream;

        stream << "25.03.2023";
        stream >> other;

        CHECK(other.getDay() == 25);
        CHECK(other.getMonth() == March);
        CHECK(other.getYear() == 2023);
        CHECK(other.getWeekday() == Saturday);
    }
}
