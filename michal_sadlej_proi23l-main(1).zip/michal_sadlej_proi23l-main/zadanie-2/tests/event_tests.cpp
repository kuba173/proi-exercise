#include "../../catch2/catch_amalgamated.hpp"
#include "../includes/event.h"
#include <sstream>

TEST_CASE("event tests", "[event]"){
    Date date(25, March, 2023);
    Time time(23, 17);
    Event event("Zadanko", date, time);

    CHECK(event.getTitle() == "Zadanko");
    CHECK(event.getDate() == date);
    CHECK(event.getTime() == time);

    SECTION("default constructor"){
        Event default_event;

        CHECK(default_event.getTitle() == "Event");
        CHECK(default_event.getDate() == Date());
        CHECK(default_event.getTime() == Time());
    }

    SECTION("title setter"){
        event.setTitle("Test");

        CHECK(event.getTitle() == "Test");
        CHECK(event.getDate() == date);
        CHECK(event.getTime() == time);
    }

    SECTION("date setter"){
        date.setYear(2022);
        event.setDate(date);

        CHECK(event.getTitle() == "Zadanko");
        CHECK(event.getDate() == date);
        CHECK(event.getTime() == time);
    }

    SECTION("time setter"){
        time.setHour(12);
        event.setTime(time);

        CHECK(event.getTitle() == "Zadanko");
        CHECK(event.getDate() == date);
        CHECK(event.getTime() == time);
    }

    SECTION("operator =="){
        Date other_date(25, March, 2023);
        Time other_time(23, 17);
        Event other("Zadanko", other_date, other_time);

        CHECK(event == other);
        other.setTitle("blabla");
        CHECK(!(event == other));
        other.setTitle("Zadanko");
        other_time.setHour(21);
        other.setTime(other_time);
        CHECK(!(event == other));
    }

    SECTION("iostream operators"){
        Event other;
        std::stringstream stream;

        stream << "Zadanko" << " " << date << " " << time;
        stream >> other;

        CHECK(other.getTitle() == "Zadanko");
        CHECK(other.getDate() == date);
        CHECK(other.getTime() == time);
    }
}
