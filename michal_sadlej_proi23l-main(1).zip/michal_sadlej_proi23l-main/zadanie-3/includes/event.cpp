/*
@author Michał Sadlej
class Event:
represents an event,
stores the title, date and time of the event,
defaults to Event on 01.01.1970 at 00:00.
*/

#include "event.h"
#include "empty_title_exception.h"

Event::Event() : title("Event"), date(Date()), time(Time()) {}

Event::Event(std::string title, Date date, Time time)
    : title(title), date(date), time(time) {
    if (title == "") {
        throw EmptyTitleException();
    }
}

std::string Event::getTitle() const { return title; }

Date Event::getDate() const { return date; }

Time Event::getTime() const { return time; }

void Event::setTitle(std::string new_title) {
    title = new_title;

    if (title == "") {
        throw EmptyTitleException();
    }
    return;
}

void Event::setDate(Date new_date) {
    date = new_date;
    return;
}

void Event::setTime(Time new_time) {
    time = new_time;
    return;
}

bool operator==(const Event &first, const Event &second) {
    return first.getTitle() == second.getTitle() &&
           first.getDate() == second.getDate() &&
           first.getTime() == second.getTime();
}

std::ostream &operator<<(std::ostream &stream, const Event &event) {
    std::string title = event.getTitle();
    Date date = event.getDate();
    Time time = event.getTime();

    stream << title << " " << date << " " << time;
    return stream;
}

std::istream &operator>>(std::istream &stream, Event &event) {
    std::string title;
    Date date;
    Time time;

    stream >> title >> date >> time;
    event.setTitle(title);
    event.setDate(date);
    event.setTime(time);

    return stream;
}

std::ostream &operator<<(std::ostream &stream,
                         const std::list<Event> &events_list) {
    for (Event event : events_list) {
        stream << "\t" << event << std::endl;
    }

    return stream;
}
