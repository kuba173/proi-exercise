#include "invalid_date_exception.h"

InvalidDateException::InvalidDateException(Date date)
    : std::invalid_argument("Given date is invalid: " + date.toString()) {}
