#include "empty_title_exception.h"

EmptyTitleException::EmptyTitleException()
    : std::invalid_argument("Title cannot be empty!") {}
