#pragma once

#include "date.h"
#include <stdexcept>

class InvalidDateException : public std::invalid_argument {
  public:
    InvalidDateException(Date);
};
