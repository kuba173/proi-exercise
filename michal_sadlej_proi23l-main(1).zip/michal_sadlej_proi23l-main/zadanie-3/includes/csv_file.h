#pragma once

#include "../../rapidcsv/rapidcsv.h"
#include "calendar.h"

class CsvFile {
  private:
    rapidcsv::Document file;

  public:
    CsvFile(std::string path);
    Calendar getCalendar() const;
};
