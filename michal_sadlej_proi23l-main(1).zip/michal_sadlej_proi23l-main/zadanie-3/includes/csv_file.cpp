/*
@author Michał Sadlej
class CsvFile:
represents a csv file,
getter returning a calendar from the csv file.
*/

#include "csv_file.h"
#include <sstream>

CsvFile::CsvFile(std::string path) : file(path) {}

Calendar CsvFile::getCalendar() const {
    std::stringstream stream;
    Calendar calendar;
    Event event;

    for (uint i = 0; i < file.GetRowCount(); i++) {
        stream << file.GetCell<std::string>("Title", i) << " "
               << file.GetCell<std::string>("Date", i) << " "
               << file.GetCell<std::string>("Time", i) << std::endl;
        stream >> event;
        stream.clear();
        calendar.addEvent(event);
    }

    return calendar;
}
