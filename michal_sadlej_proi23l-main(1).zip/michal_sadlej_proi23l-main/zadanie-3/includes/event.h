#pragma once

#include "date.h"
#include "time.h"
#include <list>
#include <string>

class Event {
  private:
    std::string title;
    Date date;
    Time time;

  public:
    Event();
    Event(std::string, Date, Time);
    std::string getTitle() const;
    Date getDate() const;
    Time getTime() const;
    void setTitle(std::string);
    void setDate(Date);
    void setTime(Time);
};

bool operator==(const Event &, const Event &);
std::ostream &operator<<(std::ostream &, const Event &);
std::istream &operator>>(std::istream &, Event &);
std::ostream &operator<<(std::ostream &, const std::list<Event> &);
