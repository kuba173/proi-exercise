#pragma once

#include "event.h"

class Calendar {
  private:
    std::list<Event> events_list;

  public:
    Calendar() = default;
    Calendar(std::list<Event>);
    std::list<Event> getEvents() const;
    std::list<Event> getEventsTitled(std::string) const;
    std::list<Event> getEventsSorted() const;
    uint countEventsOnDay(Date) const;
    uint countEventsOnWeek(Date) const;
    uint countEventsOnMonth(Date) const;
    uint countEventsTitled(std::string) const;
    void addEvent(Event);
    void removeEvent(Event);
};
