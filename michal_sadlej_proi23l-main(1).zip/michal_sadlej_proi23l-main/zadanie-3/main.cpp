/*
@author Michał Sadlej
Program reads a calendar from a csv file.
Takes the path of the csv file as an argument.
*/

#include "../rapidcsv/rapidcsv.h"
#include "includes/csv_file.h"
#include <sstream>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        std::cerr
            << "Incorrect number of command line arguments - expected 1, got "
            << argc - 1 << std::endl;
        return 1;
    }

    CsvFile csv_file(argv[1]);
    Calendar calendar = csv_file.getCalendar();

    std::cout << "Calendar:\n" << calendar.getEvents() << std::endl;
    std::cout << "Sorted:\n" << calendar.getEventsSorted() << std::endl;
    std::cout << "Exams: " << calendar.countEventsTitled("Exam") << std::endl
              << calendar.getEventsTitled("Exam") << std::endl;

    return 0;
}
