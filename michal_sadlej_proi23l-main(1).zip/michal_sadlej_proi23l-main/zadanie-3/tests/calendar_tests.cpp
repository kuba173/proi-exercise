#include "../../catch2/catch_amalgamated.hpp"
#include "../includes/calendar.h"

TEST_CASE("calendar tests", "[calendar]") {
    Date date(25, Month::March, 2023);
    Time time(23, 17);
    Event event("Zadanko", date, time);
    std::list<Event> events_list{event};
    Calendar calendar(events_list);
    std::list<Event> empty_list;

    CHECK(calendar.getEvents() == events_list);

    SECTION("default constructor") {
        Calendar default_calendar;

        CHECK(default_calendar.getEvents() == empty_list);
    }

    SECTION("get and count titled") {
        CHECK(calendar.getEventsTitled("Zadanko") == events_list);
        CHECK(calendar.getEventsTitled("blabla") == empty_list);
        CHECK(calendar.countEventsTitled("Zadanko") == 1);
        CHECK(calendar.countEventsTitled("blabla") == 0);
    }

    SECTION("count on day") {
        CHECK(calendar.countEventsOnDay(date) == 1);

        date.setDay(20);
        CHECK(calendar.countEventsOnDay(date) == 0);
    }

    SECTION("count on week") {
        CHECK(calendar.countEventsOnWeek(date) == 1);

        date.setDay(20);
        CHECK(calendar.countEventsOnWeek(date) == 1);

        date.setDay(26);
        CHECK(calendar.countEventsOnWeek(date) == 0);
    }

    SECTION("count on month") {
        CHECK(calendar.countEventsOnMonth(date) == 1);

        date.setDay(20);
        CHECK(calendar.countEventsOnMonth(date) == 1);

        date.setDay(26);
        CHECK(calendar.countEventsOnMonth(date) == 1);

        date.setMonth(Month::February);
        CHECK(calendar.countEventsOnMonth(date) == 0);
    }

    SECTION("event adder") {
        Date other_date(26, Month::March, 2023);
        Time other_time(14, 0);
        Event other_event("Test", date, time);
        calendar.addEvent(other_event);

        CHECK(calendar.getEvents() != events_list);
        events_list.push_back(other_event);
        CHECK(calendar.getEvents() == events_list);
    }

    SECTION("event remover") {
        calendar.removeEvent(event);

        CHECK(calendar.getEvents() == empty_list);
    }
}
