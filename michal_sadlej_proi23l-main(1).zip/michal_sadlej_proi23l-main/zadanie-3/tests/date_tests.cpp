#include "../../catch2/catch_amalgamated.hpp"
#include "../includes/date.h"
#include "../includes/invalid_date_exception.h"
#include <sstream>

TEST_CASE("date tests", "[date]") {
    Date date(25, Month::March, 2023);

    CHECK(date.getDay() == 25);
    CHECK(date.getMonth() == Month::March);
    CHECK(date.getYear() == 2023);
    CHECK(date.getWeekday() == Weekday::Saturday);

    SECTION("default constructor") {
        Date default_date;

        CHECK(default_date.getDay() == 1);
        CHECK(default_date.getMonth() == Month::January);
        CHECK(default_date.getYear() == 1);
        CHECK(default_date.getWeekday() == Weekday::Monday);
    }

    SECTION("invalid arguments") {
        REQUIRE_THROWS_AS(Date(29, Month::February, 2023),
                          InvalidDateException);
    }

    SECTION("day setter") {
        date.setDay(22);

        CHECK(date.getDay() == 22);
        CHECK(date.getMonth() == Month::March);
        CHECK(date.getYear() == 2023);
        CHECK(date.getWeekday() == Weekday::Wednesday);
    }

    SECTION("month setter") {
        date.setMonth(Month::February);

        CHECK(date.getDay() == 25);
        CHECK(date.getMonth() == Month::February);
        CHECK(date.getYear() == 2023);
        CHECK(date.getWeekday() == Weekday::Saturday);
    }

    SECTION("year setter") {
        date.setYear(2022);

        CHECK(date.getDay() == 25);
        CHECK(date.getMonth() == Month::March);
        CHECK(date.getYear() == 2022);
        CHECK(date.getWeekday() == Weekday::Friday);
    }

    SECTION("same week") {
        Date other(19, Month::March, 2023);

        CHECK(date.isFromSameWeek(other));
        other.setDay(26);
        CHECK(!date.isFromSameWeek(other));
        other.setDay(19);
        other.setMonth(Month::April);
        CHECK(!date.isFromSameMonth(other));
    }

    SECTION("same month") {
        Date other(19, Month::March, 2023);

        CHECK(date.isFromSameMonth(other));
        other.setMonth(Month::April);
        CHECK(!date.isFromSameMonth(other));
        other.setMonth(Month::March);
        other.setYear(2022);
    }

    SECTION("operator ==") {
        Date other(25, Month::March, 2023);

        CHECK(date == other);
        other.setDay(24);
        CHECK(!(date == other));
        other.setDay(25);
        other.setMonth(Month::February);
        CHECK(!(date == other));
        other.setMonth(Month::March);
        other.setYear(2022);
        CHECK(!(date == other));
    }

    SECTION("operator <") {
        Date other(24, Month::March, 2023);

        CHECK(other < date);
        other.setDay(25);
        CHECK(!(other < date));
        other.setMonth(Month::February);
        CHECK(other < date);
        other.setYear(2024);
        CHECK(date < other);
    }

    SECTION("iostream operators") {
        Date other;
        std::stringstream stream;

        stream << "25.03.2023";
        stream >> other;

        CHECK(other.getDay() == 25);
        CHECK(other.getMonth() == Month::March);
        CHECK(other.getYear() == 2023);
        CHECK(other.getWeekday() == Weekday::Saturday);
    }
}
