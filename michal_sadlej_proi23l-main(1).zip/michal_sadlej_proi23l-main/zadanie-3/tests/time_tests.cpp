#include "../../catch2/catch_amalgamated.hpp"
#include "../includes/invalid_time_exception.h"
#include "../includes/time.h"
#include <sstream>

TEST_CASE("time tests", "[time]") {
    Time time(19, 46);

    CHECK(time.getHour() == 19);
    CHECK(time.getMinute() == 46);

    SECTION("default constructor") {
        Time default_time;

        CHECK(default_time.getHour() == 0);
        CHECK(default_time.getMinute() == 0);
    }

    SECTION("invalid arguments") {
        REQUIRE_THROWS_AS(Time(25, 49), InvalidTimeException);
    }

    SECTION("hour setter") {
        time.setHour(9);

        CHECK(time.getHour() == 9);
        CHECK(time.getMinute() == 46);
    }

    SECTION("minute setter") {
        time.setMinute(4);

        CHECK(time.getHour() == 19);
        CHECK(time.getMinute() == 4);
    }

    SECTION("operator ==") {
        Time other(19, 46);

        CHECK(time == other);

        other.setMinute(47);

        CHECK(!(time == other));
    }

    SECTION("iostream operators") {
        Time other;
        std::stringstream stream;

        stream << "19:46";
        stream >> other;

        CHECK(other.getHour() == 19);
        CHECK(other.getMinute() == 46);
    }
}
